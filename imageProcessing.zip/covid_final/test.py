import pyzbar.pyzbar as pyzbar
from keras.models import load_model, Sequential
import sys
import os
import numpy as np
import cv2
import csv
import serial
import pygame

def csv_read(path):
  data = []
  with open(path) as f:
    reader = csv.reader(f)
    _ = next(reader)
    for idx, row in enumerate(reader):
      data.append(row)
  return np.array(data, dtype=str)

def audio(n):
    if(n==1):
        music_file = "voice1.mp3"
    if(n==2):
        music_file = "voice2.mp3"
    freq = 44100
    bitsize = -16
    channels = 1
    buffer = 2048
    pygame.mixer.init(freq, bitsize, channels, buffer)
    pygame.mixer.music.load(music_file)
    pygame.mixer.music.play()

def studentId():
    cam = cv2.VideoCapture(0)
    studentId = csv_read("C:/Users/user/PycharmProjects/covid_final/studentId.csv")
    barcode = studentId[:, 0]
    qrcocde = studentId[:, 1]

    count=1

    while(cam.isOpened()):
      ret, img = cam.read()

      if not ret:
        continue

      gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
      decoded = pyzbar.decode(gray)

      for d in decoded:
        x, y, w, h = d.rect

        barcode_data = d.data.decode("utf-8")
        barcode_type = d.type

        cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 2)

        text = '%s (%s)' % (barcode_data, barcode_type)
        cv2.putText(img, text, (x, y), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 1, cv2.LINE_AA)

        if barcode_type=='QRCODE':
          barcode_data=barcode_data[0:32]

        if barcode_type=='CODE39':
            barcode_data=barcode_data[0:7]

        if barcode_data in studentId:
            if barcode_data in qrcocde:
                index = np.where(qrcocde == barcode_data)
                barcode_data = int(barcode[index])
                barcode_data = str(barcode_data)
                cam.release()
                cv2.destroyAllWindows()
                return barcode_data

      img = cv2.resize(img,dsize=(1920,1080), interpolation=cv2.INTER_AREA)
      cv2.imshow('img', img)

      if(count==1):
          audio(1)
      count=2

      key = cv2.waitKey(1)

      if key == ord('x'):
          exit_code()
          break

    cam.release()
    cv2.destroyAllWindows()

def capture(camid=0):
    cam = cv2.VideoCapture(camid)
    count = 1
    while(cam.isOpened()):
        ret, frame = cam.read()

        if frame is None:
            print('frame is not exist')
            return None

        frame = cv2.resize(frame, dsize=(1920, 1080), interpolation=cv2.INTER_AREA)
        cv2.imshow('frame', frame)

        if (count == 1):
            audio(2)
        count = 2

        cv2.imwrite('C:/Users/user/Desktop/data/test_image/user.jpg', frame, params=[cv2.IMWRITE_PNG_COMPRESSION, 0])

        key = cv2.waitKey(1)
        if key == 13:
            cam.release()
            cv2.destroyAllWindows()
        elif key == ord('x'):
            exit_code()

def image_reult():
    categories = [
        'O',
        'X'
    ]
    def Dataization(img_path):
        image_w = 28
        image_h = 28
        img = cv2.imread(img_path)
        img = cv2.resize(img, None, fx=image_w/img.shape[1], fy=image_h/img.shape[0])
        return (img/256)

    src = []
    name = []
    test = []
    image_dir = "C:/Users/user/Desktop/data/test_image/"
    for file in os.listdir(image_dir):
        if(file.find('.jpg')is not -1):
            src.append(image_dir+file)
            name.append(file)
            test.append(Dataization(image_dir+file))

    test = np.array(test)
    model = load_model('kyung_zzu.h5')
    predict = model.predict_classes(test)
    for i in range(len(test)):
        image_data = str(categories[predict[i]])
        print(name[i] + ": , Predict : " + image_data)
        return image_data

def arduino(barcod_data,image_data):
    PORT = 'COM13'
    BaudRate = 9600
    arduino = serial.Serial(PORT, BaudRate)
    send_data=image_data+barcod_data
    send_data=send_data.encode('utf-8')
    arduino.write(send_data)

def exit_code():
    sys.exit()

while True:
    barcode_data = studentId()
    capture()
    image_data = image_reult()
    arduino(barcode_data, image_data)