package com.example.android_resapi.ui.apicall;

import android.app.Activity;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import com.example.android_resapi.R;
import com.example.android_resapi.httpconnection.GetRequest;

public class GetLog extends GetRequest {
    final static String TAG = "AndroidAPITest";
    String getLogsURL;
    public GetLog(Activity activity, String urlStr) {
        super(activity);
        this.getLogsURL = urlStr;
    }

    @Override
    protected void onPreExecute() {
        try {

            Button start_date = activity.findViewById(R.id.start_date_button);
            Button start_time = activity.findViewById(R.id.start_time_button);
            Button end_date = activity.findViewById(R.id.end_date_button);
            Button end_time = activity.findViewById(R.id.end_time_button);

            String params = String.format("?from=%s:00&to=%s:00",start_date.getText().toString()+start_time.getText().toString(),
                                                            end_date.getText().toString()+end_time.getText().toString());

            Log.i(TAG,"urlStr="+getLogsURL+params);
            url = new URL(getLogsURL+params);

        } catch (MalformedURLException e) {
            Toast.makeText(activity,"URL is invalid:"+getLogsURL, Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        TextView message = activity.findViewById(R.id.message2);
        message.setText("조회중...");
    }

    @Override
    protected void onPostExecute(String jsonString) {
        TextView message = activity.findViewById(R.id.message2);
        if (jsonString == null) {
            message.setText("로그 없음");
            return;
        }
        message.setText("");
        ArrayList<Tag> arrayList = getArrayListFromJSONString(jsonString);

        final ArrayAdapter adapter = new ArrayAdapter(activity,
                android.R.layout.simple_list_item_1,
                arrayList.toArray());
        ListView txtList = activity.findViewById(R.id.logList);
        txtList.setAdapter(adapter);
        txtList.setDividerHeight(10);
        TextView category = activity.findViewById(R.id.category);
        category.setText("        날짜    /   시간    |     학번     |   체온    |  마스크 ");
    }

    protected ArrayList<Tag> getArrayListFromJSONString(String jsonString) {
        ArrayList<Tag> output = new ArrayList();
        try {
            // 처음 double-quote와 마지막 double-quote 제거
            jsonString = jsonString.substring(1,jsonString.length()-1);
            // \\\" 를 \"로 치환
            jsonString = jsonString.replace("\\\"","\"");

            Log.i(TAG, "jsonString="+jsonString);

            JSONObject root = new JSONObject(jsonString);
            JSONArray jsonArray = root.getJSONArray("data");

            for (int i = 0; i < jsonArray.length(); i++) {

                JSONObject jsonObject = (JSONObject)jsonArray.get(i);

                Tag thing = new Tag(jsonObject.getString("ID"),
                                    jsonObject.getString("temperature"),
                                    jsonObject.getString("mask"),
                                    jsonObject.getString("timestamp"));

                output.add(thing);
            }

        } catch (JSONException e) {
            //Log.e(TAG, "Exception in processing JSONString.", e);
            e.printStackTrace();
        }
        return output;
    }

    class Tag {
        String ID;
        String temperature;
        String mask;
        String timestamp;

        public Tag(String id, String temp, String maskox, String time) {
            ID = id;
            temperature = temp;
            mask = maskox;
            timestamp = time;
        }

        public String toString() {
            return String.format("%s   |   %s   |    %s    |     %s", timestamp, ID, temperature, mask);
        }
    }
}

