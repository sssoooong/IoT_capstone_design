package com.example.android_resapi.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android_resapi.MyService;
import com.example.android_resapi.R;
import com.example.android_resapi.ui.apicall.GetThingShadow;

import java.util.Timer;
import java.util.TimerTask;

public class DeviceActivity extends AppCompatActivity {
    String urlStr;
    int checknum=0;
    final static String TAG = "AndroidAPITest";
    Timer timer;
    Button startGetBtn, alarm_start_Btn, alarm_end_Btn;
    String getLogsURL = "https://l6m2s7ldta.execute-api.ap-northeast-2.amazonaws.com/prod/devices/Project/log";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device);
        Intent intent = getIntent();
        urlStr = intent.getStringExtra("thingShadowURL");

        startGetBtn = findViewById(R.id.startGetBtn);
        startGetBtn.setEnabled(true);

        startGetBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timer = new Timer();
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        new GetThingShadow(DeviceActivity.this, urlStr).execute();
                    }
                },
                        0,2000);

                startGetBtn.setEnabled(false);
                //stopGetBtn.setEnabled(true);
            }
        });


        Button listLogButton = (Button)findViewById(R.id.listLogsBtn);
        listLogButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(DeviceActivity.this, LogActivity.class);
                intent.putExtra("getLogsURL", getLogsURL);
                startActivity(intent);
                //Intent registerIntent = new Intent(LoginActivity.this, MainActivity.class);
                //LoginActivity.this.startActivity(registerIntent);
            }
        });

        alarm_start_Btn = (Button)findViewById(R.id.Start_alarm);

        alarm_start_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if(checknum==0) {
                    alarm_start_Btn.setSelected(true);
                    Toast.makeText(getApplicationContext(), "알람 ON", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(DeviceActivity.this, MyService.class);
                    startService(intent);
                    checknum =1 ;
                }
               else{
                   alarm_start_Btn.setSelected(false);
                   Toast.makeText(getApplicationContext(),"알람 OFF", Toast.LENGTH_SHORT).show();
                   Intent intent = new Intent(DeviceActivity.this,MyService.class);
                   stopService(intent);
                   checknum =0 ;
               }
            }
        });

//        alarm_end_Btn.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v) {
//            }
//        });

    }

    private void clearTextView() {
        TextView reported_idTV = findViewById(R.id.reported_id);
        TextView reported_tempTV = findViewById(R.id.reported_temp);
        TextView reported_maskTV = findViewById(R.id.reported_mask);
        reported_idTV.setText("");
        reported_tempTV.setText("");
        reported_maskTV.setText("");
    }
}


