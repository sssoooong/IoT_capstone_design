package com.example.android_resapi.ui;
import android.os.Message;
import android.os.Handler;

import com.example.android_resapi.ui.apicall.GetThingShadow;

public class ServiceThread extends Thread {
    Handler handler;
    boolean isRun = true;

    public ServiceThread(Handler handler) {
        this.handler = handler;
    }

    public void stopForever() {
        synchronized (this) {
            this.isRun = false;
        }
    }

    public void run() {
        while (isRun) {
            handler.sendEmptyMessage(0);
            try {
                Thread.sleep(30000);
            } catch (Exception e) {
            }
        }
    }
}
