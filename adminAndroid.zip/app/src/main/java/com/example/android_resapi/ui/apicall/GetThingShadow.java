package com.example.android_resapi.ui.apicall;

import android.app.Activity;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONException;
import org.json.JSONObject;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import com.example.android_resapi.MyService;
import com.example.android_resapi.R;
import com.example.android_resapi.httpconnection.GetRequest;
import com.example.android_resapi.ui.LoginActivity;


public class GetThingShadow extends GetRequest {
    final static String TAG = "AndroidAPITest";
    String URL;
    public static String a = "reset" ;
    public static double temp_int;


    public GetThingShadow(Activity activity, String urlStr) {
        super(activity);
        this.URL = urlStr;
    }

    public GetThingShadow(LoginActivity loginActivity) {
        super(loginActivity);
    }


    @Override
    protected void onPreExecute() {
        try {
            Log.e(TAG, URL);
            url = new URL(URL);

        } catch (MalformedURLException e) {
            Toast.makeText(activity,"URL is invalid:"+URL, Toast.LENGTH_SHORT).show();
            e.printStackTrace();
            activity.finish();
        }
    }

    @Override
    protected void onPostExecute(String jsonString) {
        if (jsonString == null)
            return;
        Map<String, String> state = getStateFromJSONString(jsonString);
        ImageView reported_image = activity.findViewById(R.id.imageView);
        TextView reported_name = activity.findViewById(R.id.name);
        TextView reported_idTV = activity.findViewById(R.id.reported_id);
        TextView reported_tempTV = activity.findViewById(R.id.reported_temp);
        TextView reported_maskTV = activity.findViewById(R.id.reported_mask);
        reported_idTV.setText(state.get("reported_id"));
        reported_tempTV.setText(state.get("reported_temperature"));
        reported_maskTV.setText(state.get("reported_mask"));
        a="reported_temperature";

        if(state.get("reported_id").equals("1771116"))
        {
//          String a="R.drawable.";
            reported_image.setImageResource(R.drawable.img_1771116);
            reported_name.setText("백 민 진 [사이버보안트랙]");
        }
        if(state.get("reported_id").equals("1771132"))
        {
            reported_image.setImageResource(R.drawable.img_1771132);
            reported_name.setText("송 경 주 [사이버보안트랙]");
        }

        if(state.get("reported_id").equals("1791126"))
        {
            reported_image.setImageResource(R.drawable.img_1791126);
            reported_name.setText("강 혜 진 [사물인터넷트랙]");
        }

        temp_int = Double.parseDouble(state.get("reported_temperature"));

    }

    protected Map<String, String> getStateFromJSONString(String jsonString) {
        Map<String, String> output = new HashMap<>();
        try {
            // 처음 double-quote와 마지막 double-quote 제거
            jsonString = jsonString.substring(1,jsonString.length()-1);
            // \\\" 를 \"로 치환
            jsonString = jsonString.replace("\\\"","\"");
            Log.i(TAG, "jsonString="+jsonString);
            JSONObject root = new JSONObject(jsonString);
            JSONObject state = root.getJSONObject("state");
            JSONObject reported = state.getJSONObject("reported");
            String idValue = reported.getString("id");
            String tempValue = reported.getString("temperature");
            String maskValue = reported.getString("mask");
            output.put("reported_id",idValue);
            output.put("reported_temperature", tempValue);
            output.put("reported_mask", maskValue);



        } catch (JSONException e) {
            Log.e(TAG, "Exception in processing JSONString.", e);
            e.printStackTrace();
        }
        return output;
    }


}