package com.example.android_resapi.ui;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android_resapi.MyService;
import com.example.android_resapi.R;
import com.example.android_resapi.ui.apicall.GetThingShadow;

public class LoginActivity extends AppCompatActivity {

    String URL = "https://l6m2s7ldta.execute-api.ap-northeast-2.amazonaws.com/prod/devices/Project";
    private Button btnStart, btnEnd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        final EditText idText = (EditText)findViewById(R.id.idText);
        final EditText passwordText = (EditText)findViewById(R.id.passwordText);
        Button loginButton = (Button)findViewById(R.id.loginButton);
//        btnStart = (Button)findViewById(R.id.Start_alarm);
//        btnEnd = (Button)findViewById(R.id.Stop_alarm);


        loginButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String adminidText = idText.getText().toString();
                String adminpasswordText = passwordText.getText().toString();

                if(adminidText.equals("root") && adminpasswordText.equals("1771116"))
                {
                    Intent intent = new Intent(LoginActivity.this, DeviceActivity.class);
                    intent.putExtra("thingShadowURL", URL);
                    startActivity(intent);
                    //Intent registerIntent = new Intent(LoginActivity.this, MainActivity.class);
                    //LoginActivity.this.startActivity(registerIntent);
                }
                else{
                    Toast.makeText(LoginActivity.this, "관리자 정보가 잘못됐습니다.", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        });

//        btnStart.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(getApplicationContext(),"Service 시작",Toast.LENGTH_SHORT).show();
//                Intent intent = new Intent(LoginActivity.this,MyService.class);
//                startService(intent);
//            }
//        });

//        btnEnd.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(getApplicationContext(),"Service 끝", Toast.LENGTH_SHORT).show();
//                Intent intent = new Intent(LoginActivity.this,MyService.class);
//                stopService(intent);
//            }
//        });
    }

}
